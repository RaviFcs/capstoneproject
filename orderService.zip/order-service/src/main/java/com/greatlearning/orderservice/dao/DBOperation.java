package com.greatlearning.orderservice.dao;

import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.Table;

@Component
public class DBOperation {
	private AmazonDynamoDB amazonDynamoDBClient = null;
	private DynamoDB dynamoDB = null;
	@Value("${accessKey}")
	private String accessKey;
	@Value("${secretKey}")
	private String secretKey;
	@Value("${tableName}")
	private String tableName;

	public void insertData(Summary summary) {
		BasicAWSCredentials awsCredentials = new BasicAWSCredentials(accessKey, secretKey);
		amazonDynamoDBClient = AmazonDynamoDBClientBuilder.standard()
				.withCredentials(new AWSStaticCredentialsProvider(awsCredentials)).withRegion(Regions.US_WEST_2)
				.build();
		dynamoDB = new DynamoDB(amazonDynamoDBClient);
		Table table = dynamoDB.getTable(tableName);
		Item item = new Item();
		item.withPrimaryKey("userName", summary.getUserName());
		item.withString("productName", summary.getProductName());
		item.withString("date", new Date().toString());
		item.withNumber("quantity", summary.getQuantity());
		item.withNumber("price", summary.getPrice());
		table.putItem(item);
	}
}
