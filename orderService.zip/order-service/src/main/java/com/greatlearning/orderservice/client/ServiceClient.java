package com.greatlearning.orderservice.client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.cloudformation.AmazonCloudFormation;
import com.amazonaws.services.cloudformation.AmazonCloudFormationClientBuilder;
import com.amazonaws.services.cloudformation.model.DescribeStacksRequest;
import com.amazonaws.services.cloudformation.model.DescribeStacksResult;
import com.amazonaws.services.cloudformation.model.Output;
import com.amazonaws.services.cloudformation.model.Stack;
import com.greatlearning.orderservice.dao.DBOperation;
import com.greatlearning.orderservice.dao.Summary;

@RestController
public class ServiceClient {

	@Autowired
	DBOperation dbOperation;

	@Autowired
	RestTemplate restTemplate;

	@Value("${cart.url}")
	private String url;
	@Value("${accessKey}")
	private String accessKey;
	@Value("${secretKey}")
	private String secretKey;
	@Value("${stackName}")
	private String stackName;
	@Value("${cartEndpoint}")
	private String cartEndpoint;

	@PostMapping(path = "/checkout", consumes = "application/json")
	public String placeOrder(@RequestBody Summary summary) {
		Stack actualStack = null;
		String outputURL = null;
		dbOperation.insertData(summary);
		BasicAWSCredentials awsCredentials = new BasicAWSCredentials(accessKey, secretKey);
		AmazonCloudFormation amazonCloudFormation = AmazonCloudFormationClientBuilder.standard()
				.withCredentials(new AWSStaticCredentialsProvider(awsCredentials)).withRegion(Regions.US_WEST_2)
				.build();
		DescribeStacksResult describeStacksResult = amazonCloudFormation.describeStacks(new DescribeStacksRequest());
		for (Stack stack : describeStacksResult.getStacks()) {
			if (stack.getStackName().equalsIgnoreCase(stackName)) {
				actualStack = stack;
			}
		}
		for (Output output : actualStack.getOutputs()) {
			if (output.getOutputKey().equalsIgnoreCase(cartEndpoint)) {
				outputURL = output.getOutputValue();
			}
		}
		String fullURL = outputURL + ":8081" + url + summary.getUserName();
		restTemplate.getForObject(fullURL, String.class);
		return "Success";
	}

	@GetMapping
	public String status() {
		return "Ok";
	}
}
